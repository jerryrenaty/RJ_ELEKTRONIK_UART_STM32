#ifndef INC_RJ_ELEKTRONIK_UART_H_
#define INC_RJ_ELEKTRONIK_UART_H_

#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

/* ==================== */
/*  Configuration       */
/* ==================== */
#define UART_TX_PIN          GPIO_PIN_9
#define UART_RX_PIN          GPIO_PIN_10
#define UART_GPIO_PORT       GPIOA
#define UART_INSTANCE        USART1
#define UART_BUFFER_SIZE     128
#define UART_TIMEOUT_MS      1000

/* ==================== */
/*  Déclaration UART    */
/* ==================== */
void UART_Init(uint32_t baudrate);

/* -------------------- */
/*  Fonctions d'émission */
/* -------------------- */
void UART_Write(char c);
void UART_WriteString(const char *str);
int UART_Print(const char *format, ...);  // Retourne maintenant le nombre de caractères écrits

/* -------------------- */
/*  Fonctions de réception */
/* -------------------- */
char UART_Read();
int UART_Available();
int UART_ReadBuffer(uint8_t *buffer, uint32_t size);  // Nouvelle fonction

#endif /* INC_RJ_ELEKTRONIK_UART_H_ */
