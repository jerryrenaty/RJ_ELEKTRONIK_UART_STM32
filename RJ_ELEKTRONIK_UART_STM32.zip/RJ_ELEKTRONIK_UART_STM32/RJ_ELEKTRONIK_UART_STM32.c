#include "RJ_ELEKTRONIK_UART_STM32.h"
#include "stm32f1xx_hal.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

/* ==================== */
/*  Variables globales  */
/* ==================== */
static UART_HandleTypeDef huart1;

/* ==================== */
/*  Implémentation      */
/* ==================== */

void UART_Init(uint32_t baudrate) {
    // Activation des horloges
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_USART1_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Configuration TX
    GPIO_InitStruct.Pin = UART_TX_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(UART_GPIO_PORT, &GPIO_InitStruct);

    // Configuration RX
    GPIO_InitStruct.Pin = UART_RX_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(UART_GPIO_PORT, &GPIO_InitStruct);

    // Configuration UART
    huart1.Instance = UART_INSTANCE;
    huart1.Init.BaudRate = baudrate;
    huart1.Init.WordLength = UART_WORDLENGTH_8B;
    huart1.Init.StopBits = UART_STOPBITS_1;
    huart1.Init.Parity = UART_PARITY_NONE;
    huart1.Init.Mode = UART_MODE_TX_RX;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart1);
}

void UART_Write(char c) {
    HAL_UART_Transmit(&huart1, (uint8_t*)&c, 1, UART_TIMEOUT_MS);
}

void UART_WriteString(const char *str) {
    HAL_UART_Transmit(&huart1, (uint8_t*)str, strlen(str), UART_TIMEOUT_MS);
}

int UART_Print(const char *format, ...) {
    char buffer[UART_BUFFER_SIZE];
    va_list args;
    int len;

    va_start(args, format);
    len = vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);

    // Protection contre le débordement
    if (len < 0) {
        return -1;  // Erreur de formatage
    } else if ((unsigned int)len >= sizeof(buffer)) {
        len = sizeof(buffer) - 1;  // Tronquer pour s'adapter au buffer
        buffer[len] = '\0';        // Assurer la terminaison
    }

    UART_WriteString(buffer);
    return len;
}

char UART_Read() {
    char c;
    HAL_UART_Receive(&huart1, (uint8_t*)&c, 1, UART_TIMEOUT_MS);
    return c;
}

int UART_Available() {
    // Vérifie plusieurs flags pour une meilleure robustesse
    if (__HAL_UART_GET_FLAG(&huart1, UART_FLAG_RXNE) == SET) {
        return 1;
    }
    if (__HAL_UART_GET_FLAG(&huart1, UART_FLAG_ORE) == SET) {
        __HAL_UART_CLEAR_OREFLAG(&huart1);
    }
    if (__HAL_UART_GET_FLAG(&huart1, UART_FLAG_NE) == SET) {
        __HAL_UART_CLEAR_NEFLAG(&huart1);
    }
    return 0;
}

int UART_ReadBuffer(uint8_t *buffer, uint32_t size) {
    if (buffer == NULL || size == 0) {
        return -1;
    }

    uint32_t bytesRead = 0;
    while (bytesRead < size && UART_Available()) {
        HAL_UART_Receive(&huart1, &buffer[bytesRead], 1, UART_TIMEOUT_MS);
        bytesRead++;
    }

    return bytesRead;
}
